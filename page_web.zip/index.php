<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>207CC</title>
 
<style>
    body{
        margin:0px 0px;
        padding: 0;
        background-color: black;
        overflow-y :hidden;
    }

    div{
        margin: 0;
        padding: 0;
    }

    video {
        height: 85vh;
        margin: 0px 0px;
        margin-top: 1%;
        padding: 0;
    }

    #container {
        margin: 0px 0px;
        padding: 0;
        background-color: black;
        text-align: center;
        border: none;
        border-bottom: none;
    }
    #videoElement {
        /*transform: rotateY(180deg);
        -webkit-transform:rotateY(180deg); 
        -moz-transform:rotateY(180deg);*/
        background-color: red;
        padding: 0;
        margin: 0;
        border: none;
        border-bottom: none;
    }

    #CLIM {
        /*display : table-row;*/
        margin: 0px 0px;
        padding: 0;
        border: none;
        text-align: center;
        background-color: black;
        min-height: 9vh;
        max-height: 10vh;
        width: 100%;
    }

    .icon{
        margin-left: 9%;
        /*margin-right: 15%;*/
        float: left;
        height: 50px;
        width: auto;
    }

    .temp img{
        height: 20px;
        width: auto;
    }

    .temp{
        margin-left: 6%;
        /*display:inline-block;
        /*margin-left: 3.5%;*/
        float: left;
        /*height: auto;
        width: 25px;*/
        text-align: center;
    }
    /*
    .temp > * {
        vertical-align:middle;
    }*/

    .temperature_texte{
        /*font-style: normal;*/
        font-weight: bold;
        text-decoration-style: none;
        color: antiquewhite;
        margin: 0px 0px;
        /*margin-left: 33%;*/
        text-align: center;
    }

    .power{
        margin-left: 9%;
        /*margin-left: auto;*/
        margin-right: auto;
        /*margin-top: 1%;*/
        /*margin-left: 3.5%;*/
        float: left;
        height: auto;
        width: 7%;
        text-align: center;
        /*background-color: aqua;*/
    }

    .power{
        text-align: center;
    }
    #text_power_status{
        display: inline-block;
        font-weight: bold;
        text-decoration-style: none;
        color: antiquewhite;
        margin: 0px 0px;
        text-align: center;
    }
    .test img{
        height: 28px;
        width: auto;
        text-align: center;
    }

    #speed_selector{
        display: none;
    }
    #speed_selector2{
        display: none;
    }

</style>
</head>
 
<body>
<div id="container">
    <!--<video autoplay="true" id="videoElement">
    </video>-->
    <?php
        $txt_file = fopen('/var/www/html/Can/can_frame.txt','r');
        while ($line = fgets($txt_file)) {
        $tram = $line;
        }
        fclose($txt_file);
        $tram = str_split($tram, 2);
        //print_r($tram);


        $txt_file = fopen('/var/www/html/Can/save_status.txt','r');
        $a=1;
        while ($line = fgets($txt_file)) {
        if ($a == 1){
            $clim_text_power = $line;
            $clim_text_power = substr($clim_text_power, 16);
        }
        if ($a == 2){
            $bue_arriere = $line;
            $bue_arriere = substr($line, 12);
            $test = str_split($bue_arriere,1);
            if($test[0] == "t"){
                $bue_arriere = "true";
            }else{
                $bue_arriere = "false";
            }
        }
        $a++;
        }
        fclose($txt_file);

        function clim_hex_to_asci($temp){
            if($temp == "00"){
                return "LO";
            }else if ($temp == "01"){
                return "14";
            }else if ($temp == "02"){
                return "15";
            }else if ($temp == "03"){
                return "16";
            }else if ($temp == "04"){
                return "17";
            }else if ($temp == "05"){
                return "18";
            }else if ($temp == "06"){
                return "18.5";
            }else if ($temp == "07"){
                return "19";
            }else if ($temp == "08"){
                return "19.5";
            }else if ($temp == "09"){
                return "20";
            }else if ($temp == "0A"){
                return "20.5";
            }else if ($temp == "0B"){
                return "21";
            }else if ($temp == "0C"){
                return "21.5";
            }else if ($temp == "0D"){
                return "22";
            }else if ($temp == "0E"){
                return "22.5";
            }else if ($temp == "0F"){
                return "23";
            }else if ($temp == "10"){
                return "23.5";
            }else if ($temp == "11"){
                return "24";
            }else if ($temp == "12"){
                return "25";
            }else if ($temp == "13"){
                return "26";
            }else if ($temp == "14"){
                return "27";
            }else if ($temp == "15"){
                return "28";
            }else if ($temp == "16"){
                return "HI";
            }
        }
    ?>
    <?php
        include "test-webcam-mic-master/index.html";
    ?>

</div>
<!--<button onclick="myFunction()">Click me</button>-->
<script>
    full=0;

    function fullscreen() {
        var docElm = document.documentElement;
        if (docElm.requestFullscreen) {
            docElm.requestFullscreen();
        } else if (docElm.mozRequestFullScreen) {
            docElm.mozRequestFullScreen();
        } else if (docElm.webkitRequestFullScreen) {
            docElm.webkitRequestFullScreen();
        }
        full=1;
        }

    function exitFullscreen() {
        if (document.cancelFullScreen) {
            document.cancelFullScreen();}
            else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
            }
            else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
            }
            else if (document.msExitFullscreen) {
            document.msExitFullscreen();
            } 
        full=0;
    }

    const card = document.querySelector('div');
    card.addEventListener('dblclick', function (e) {
        if ( full == 0){
            fullscreen();
        }else{
            exitFullscreen();
        }
    });

    var taillescreen_netflix;

    function myFunction() {
        taillescreen_netflix = 1920;
    }

    // OK
    // VIDEO STREAM 
    /*var video = document.querySelector("#videoElement");
    if (navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: {
        facingMode: 'environment',
        width: {
            //min: 1920
            min:640
        },
        height: {
            //min: 720
            min:480
        }}})
        .then(function (stream) {
        video.srcObject = stream;
        audio.srcObject = stream;
        })
        .catch(function (err0r) {
        console.log("Something went wrong!");
        });
    }*/

    /*
    * VARIABLE 
    */
    /*var clim_temp_left = 21;
    var clim_temp_right = 21;
    var bue_avant = false;
    var bue_arriere = false;
    var clim_RECYLE_AIR = false;
    var clim_text_power = "OFF";
    var clim_speedfan_power = 0;
    var clim_position = 16;*/

    var clim_temp_left = <?php echo clim_hex_to_asci($tram[7]); ?>;
    var clim_temp_right = <?php echo clim_hex_to_asci($tram[8]); ?>;
    var bue_avant = <?php if($tram[2] == "11"){ echo "true";
        }else{ echo "false";} ?>;
    var bue_arriere = <?php echo $bue_arriere; ?>;
    //console.log(bue_arriere);
    var clim_RECYLE_AIR = <?php if($tram[6] == "30"){ echo "true";}else{ echo "false";}; ?>;
    var clim_text_power = "<?php echo str_replace("\n","",$clim_text_power); ?>";
    //console.log(clim_text_power);
    var clim_speedfan_power = <?php echo $tram[4]; ?>;
    var clim_position = <?php echo $tram[5]; ?>;



    function send_action(){
        var str = "clim_temp_left="+clim_temp_left+"&clim_temp_right="+clim_temp_right+"&bue_avant="+bue_avant+"&bue_arriere="+bue_arriere+"&clim_RECYLE_AIR="+clim_RECYLE_AIR+"&clim_text_power="+clim_text_power+"&clim_speedfan_power="+clim_speedfan_power+"&clim_position="+clim_position;
        console.log(str);
        fetch("https://127.0.0.1/Can/test.php", {
            method: "POST",
            headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            },
            body: str
        });
    }

    function clim_bue_avant(){
        if(bue_avant == false){
            document.getElementById("clim_bue_avant").src="Images/Fan/BUE/bue_avant_ON.png";
            bue_avant = true;
            clim_text_power="Manuel";
            clim_power();
        }else{
            document.getElementById("clim_bue_avant").src="Images/Fan/BUE/bue_avant.png";
            bue_avant = false;
            send_action();
        } 
        
    }

    function clim_temp_left_up(){
        if(clim_temp_left == 29) return;
        if(clim_temp_left == 18 || clim_temp_left == 18.5 || clim_temp_left == 19 || clim_temp_left == 19.5 
        || clim_temp_left == 20 || clim_temp_left == 20.5 || clim_temp_left == 21 || clim_temp_left == 21.5 
        || clim_temp_left == 22 || clim_temp_left == 22.5 || clim_temp_left == 23 || clim_temp_left == 23.5){
            clim_temp_left = clim_temp_left + 0.5;
        }else{
            clim_temp_left = clim_temp_left + 1;
        }
        if(clim_temp_left == 29){
            document.getElementById("text_temp_left").innerHTML = "HI";
        }else{
            document.getElementById("text_temp_left").innerHTML = clim_temp_left;
        }
        send_action();
    }

    function clim_temp_left_down(){
        if(clim_temp_left == 13) return;
        if(clim_temp_left == 18.5 || clim_temp_left == 19 || clim_temp_left == 19.5 
        || clim_temp_left == 20 || clim_temp_left == 20.5 || clim_temp_left == 21 || clim_temp_left == 21.5 
        || clim_temp_left == 22 || clim_temp_left == 22.5 || clim_temp_left == 23 || clim_temp_left == 23.5
        ||clim_temp_left == 24 || clim_temp_left == 24.5){
            clim_temp_left = clim_temp_left - 0.5;
        }else{
            clim_temp_left = clim_temp_left - 1;
        }
        if(clim_temp_left == 13){
            document.getElementById("text_temp_left").innerHTML = "LO";
        }else{
            document.getElementById("text_temp_left").innerHTML = clim_temp_left;
        }
        send_action();
    }

    function clim_recycle_air(){
        if(clim_RECYLE_AIR == false){
            document.getElementById("clim_RECYLE_AIR").src="Images/Fan/RECYCLE_AIR/Recycle_48.png";
            clim_RECYLE_AIR = true;
        }else{
            document.getElementById("clim_RECYLE_AIR").src="Images/Fan/RECYCLE_AIR/Recycle_0.png";
            clim_RECYLE_AIR = false;
        }
        send_action();
    }

    function clim_power_speedfan_up(){
        if(clim_text_power != "Manuel")return;
        if(clim_speedfan_power == 7) return;
        clim_speedfan_power = clim_speedfan_power  + 1;
        document.getElementById("powerimg").src="Images/Fan/Status/power"+clim_speedfan_power+".png";
        send_action();
    }

    function clim_power(){
        if(clim_text_power == "OFF"){
            clim_text_power = "Manuel";
        }else if(clim_text_power == "Manuel"){
            clim_text_power = "Auto";
        }else if(clim_text_power == "Auto"){
            clim_text_power = "Auto A/C";
        }else if(clim_text_power == "Auto A/C"){
            clim_text_power = "OFF";
        }
        if(clim_text_power == "Manuel"){
            document.getElementById("speed_selector").style.display = "unset";
            document.getElementById("speed_selector2").style.display = "unset";
        }else{
            document.getElementById("speed_selector").style.display = "none";
            document.getElementById("speed_selector2").style.display = "none";
            clim_speedfan_power = 0;
            document.getElementById("powerimg").src="Images/Fan/Status/power"+clim_speedfan_power+".png";
        }
        document.getElementById("text_power_status").innerHTML = clim_text_power;
        send_action();
    }

    function clim_power_speedfan_down(){
        if(clim_text_power != "Manuel")return;
        if(clim_speedfan_power == 0) return;
        clim_speedfan_power = clim_speedfan_power - 1;
        document.getElementById("powerimg").src="Images/Fan/Status/power"+clim_speedfan_power+".png";
        send_action();
    }

    function clim_change_position(){
        if(clim_position == 16){
            clim_position = 96;
        }else if(clim_position == 96){
            clim_position = 64;
        }else if(clim_position == 64){
            clim_position = 48;
        }else if(clim_position == 48){
            clim_position = 80;
        }else if(clim_position == 80){
            clim_position = 32;
        }else if(clim_position == 32){
            clim_position = 16;
        }
        document.getElementById("clim_position").src="Images/Fan/POSITION/position_"+clim_position+".png";
        send_action();
    }

    function clim_temp_right_up(){
        if(clim_temp_right == 29) return;
        if(clim_temp_right == 18 || clim_temp_right == 18.5 || clim_temp_right == 19 || clim_temp_right == 19.5 
        || clim_temp_right == 20 || clim_temp_right == 20.5 || clim_temp_right == 21 || clim_temp_right == 21.5 
        || clim_temp_right == 22 || clim_temp_right == 22.5 || clim_temp_right == 23 || clim_temp_right == 23.5){
            clim_temp_right = clim_temp_right + 0.5;
        }else{
            clim_temp_right = clim_temp_right + 1;
        }
        if(clim_temp_right == 29){
            document.getElementById("text_temp_right").innerHTML = "HI";
        }else{
            document.getElementById("text_temp_right").innerHTML = clim_temp_right;
        }
        send_action();
    }
    function clim_temp_right_down(){
        if(clim_temp_right == 13) return;
        if(clim_temp_right == 18.5 || clim_temp_right == 19 || clim_temp_right == 19.5 
        || clim_temp_right == 20 || clim_temp_right == 20.5 || clim_temp_right == 21 || clim_temp_right == 21.5 
        || clim_temp_right == 22 || clim_temp_right == 22.5 || clim_temp_right == 23 || clim_temp_right == 23.5
        ||clim_temp_right == 24 || clim_temp_right == 24.5){
            clim_temp_right = clim_temp_right - 0.5;
        }else{
            clim_temp_right = clim_temp_right - 1;
        }
        if(clim_temp_right == 13){
            document.getElementById("text_temp_right").innerHTML = "LO";
        }else{
            document.getElementById("text_temp_right").innerHTML = clim_temp_right;
        }
        send_action();
    }

    function clim_bue_arriere(){
        if(bue_arriere == false){
            document.getElementById("clim_bue_arriere").src="Images/Fan/BUE/bue_arriere_ON.png";
            bue_arriere=true;
            clim_text_power="Manuel";
            clim_power();
        }else{
            document.getElementById("clim_bue_arriere").src="Images/Fan/BUE/bue_arriere.png";
            bue_arriere=false;
            send_action(); //car climpower execute déjà sendaction
        }

    }


</script>

<div id="CLIM">
    <img id="clim_bue_avant" class="icon" <?php if($tram[2] == "11"){ echo "src='Images/Fan/BUE/bue_avant_ON.png'";
        }else{ echo "src='Images/Fan/BUE/bue_avant.png'";} ?>; onclick="clim_bue_avant()">

    <div class="temp">
        <img id="temp_selector" src="Images/Fan/temperature/up.png" onclick="clim_temp_left_up()">
        <p id="text_temp_left" class="temperature_texte"><?php echo clim_hex_to_asci($tram[7]); ?></p>
        <img id="temp_selector" src="Images/Fan/temperature/down.png" onclick="clim_temp_left_down()">
    </div>

    <img id="clim_RECYLE_AIR" class="icon" <?php if($tram[6] == "30"){echo "src='Images/Fan/RECYCLE_AIR/Recycle_48.png'";}else{echo "src='Images/Fan/RECYCLE_AIR/Recycle_0.png'";}; ?>; onclick="clim_recycle_air()">

        
    <div class="power">
        <p id="text_power_status"><?php echo str_replace("\n","",$clim_text_power); ?></p><br>
        <div class="test">
            <img id="speed_selector" src="Images/Fan/arrow/left.png" onclick="clim_power_speedfan_down()">
            <img id="powerimg" src="Images/Fan/Status/power0.png" onclick="clim_power()">
            <img id="speed_selector2" src="Images/Fan/arrow/right.png" onclick="clim_power_speedfan_up()">
        </div>
    </div>
    <script>
        if(clim_text_power == "Manuel"){
            document.getElementById("speed_selector").style.display = "unset";
            document.getElementById("speed_selector2").style.display = "unset";
        }
    </script>

    
    <img id="clim_position" class="icon" src="Images/Fan/POSITION/position_<?php echo $tram[5]; ?>.png" onclick="clim_change_position()">

    <div class="temp">
        <img id="temp_selector" class="icon" src="Images/Fan/temperature/up.png" onclick="clim_temp_right_up()">
        <p id="text_temp_right" class="temperature_texte"><?php echo clim_hex_to_asci($tram[8]); ?></p>
        <img id="temp_selector" class="icon" src="Images/Fan/temperature/down.png" onclick="clim_temp_right_down()">
    </div>

    <img id="clim_bue_arriere" class="icon" <?php if("$bue_arriere" == "true"){ echo "src='Images/Fan/BUE/bue_arriere_ON.png'"; }else{  echo "src='Images/Fan/BUE/bue_arriere.png'"; } ?> onclick="clim_bue_arriere()">
</div>


</body>
</html>
