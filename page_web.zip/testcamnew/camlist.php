<?php

echo htmlspecialchars($_POST['camdefault']);
echo "</br>";
echo htmlspecialchars($_POST['camsecond']);

$camfile="camlist";
$myfile = fopen($camfile, "w") or die("");
$txt = $_POST['camdefault']."\n";
fwrite($myfile, $txt);
$txt = $_POST['camsecond']."\n";
fwrite($myfile, $txt);
fclose($myfile);

echo "<script>window.location = 'https://127.0.0.1'</script>";

?>