<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>207CC</title>
</head>
<body>
    <select id="audioSource">
    </select>
    <select id="videoSource">
    </select>
    <br>
    <video id="video" autoplay></video>
</body>

<script>
    function toggleFullScreen() {
    if (!document.fullscreenElement) {

        var elem = document.getElementById("video");
        if (elem.requestFullscreen) {
        elem.requestFullscreen();
        } else if (elem.mozRequestFullScreen) {
        elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) {
        elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) {
        elem.msRequestFullscreen();
        }

    } else {
        if (document.exitFullscreen) {
        document.exitFullscreen();
        }
    }
    }

    document.addEventListener("keydown", function(e) {
    if (e.keyCode == 13) {
        console.log('enter')
        toggleFullScreen();
    }
    }, false);

    const card = document.querySelector('body');
    card.addEventListener('dblclick', function (e) {
        console.log('enter')
        toggleFullScreen();
    });

    const hdConstraints = {
    //video: {width: {min: 1280}, height: {min: 720}}
    video: {width: {min: 1080}, height: {min: 720}}
    };

    navigator.mediaDevices.getUserMedia(hdConstraints).
    then((stream) => {video.srcObject = stream});

    const video = document.querySelector('video');

    const videoElement = document.querySelector('video');
    const audioSelect = document.querySelector('select#audioSource');
    const videoSelect = document.querySelector('select#videoSource');

    navigator.mediaDevices.enumerateDevices()
    .then(gotDevices).then(getStream).catch(handleError);

    audioSelect.onchange = getStream;
    videoSelect.onchange = getStream;

    function gotDevices(deviceInfos) {
    for (let i = 0; i !== deviceInfos.length; ++i) {
        const deviceInfo = deviceInfos[i];
        const option = document.createElement('option');
        option.value = deviceInfo.deviceId;
        if (deviceInfo.kind === 'audioinput') {
        option.text = deviceInfo.label ||
            'microphone ' + (audioSelect.length + 1);
        audioSelect.appendChild(option);
        } else if (deviceInfo.kind === 'videoinput') {
        option.text = deviceInfo.label || 'camera ' +
            (videoSelect.length + 1);
        videoSelect.appendChild(option);
        } else {
        console.log('Found another kind of device: ', deviceInfo);
        }
    }
    }

    function getStream() {
    if (window.stream) {
        window.stream.getTracks().forEach(function(track) {
        track.stop();
        });
    }

    const constraints = {
        audio: {
        deviceId: {exact: audioSelect.value}
        },
        video: {
            deviceId: {exact: videoSelect.value},
            facingMode: 'environment',
            width: {
                min: 1080
                //min:640
            },
            height: {
                min: 720
                //min:480
            }
        }
    };

    navigator.mediaDevices.getUserMedia(constraints).
        then(gotStream).catch(handleError);
    }

    function gotStream(stream) {
    window.stream = stream; // make stream available to console
    videoElement.srcObject = stream;
    }

    function handleError(error) {
    console.error('Error: ', error);
    }
</script>

</html>