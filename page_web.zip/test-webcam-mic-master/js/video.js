/*
 *  Copyright (c) 2015 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree.
 */

'use strict';

var errorElement = document.querySelector('#errorMsg');
var video = document.querySelector('video');


// Put variables in global scope to make them available to the browser console.
var constraints = window.constraints = {
  audio: false,
  video: {
    optional: [
        {sourceId: "cc88f17234eb169725b9c963fb1e0e00b0b6000a517556778a0ac03a6cb06508"} /* CHanger par le device id de la nouvelle cam on peut l'avoir de la console deplier le (promise et array)*/
    ]
  }
};

// cc88f17234eb169725b9c963fb1e0e00b0b6000a517556778a0ac03a6cb06508
// 282218c88fe8f07e9b17b8161b6643087fe4197d30585bfb946a5a91554681de
console.log(navigator.mediaDevices.enumerateDevices());

/*{
    deviceId: { exact: "cc88f17234eb169725b9c963fb1e0e00b0b6000a517556778a0ac03a6cb06508" }
  }*/


function handleSuccess(stream) {
  var videoTracks = stream.getVideoTracks();
  console.log('Got stream with constraints:', constraints);
  console.log('Using video device: ' + videoTracks[0].label);
  stream.oninactive = function() {
    console.log('Stream inactive');
    videoTracks = stream.getVideoTracks();
  };
  window.stream = stream; // make variable available to browser console
  video.srcObject = stream;
}

function handleError(error) {
  if (error.name === 'ConstraintNotSatisfiedError') {
    errorMsg('The resolution ' + constraints.video.width.exact + 'x' +
        constraints.video.width.exact + ' px is not supported by your device.');
  } else if (error.name === 'PermissionDeniedError') {
    errorMsg('Permissions have not been granted to use your camera and ' +
      'microphone, you need to allow the page access to your devices in ' +
      'order for the demo to work.');
  }
  errorMsg('getUserMedia error: ' + error.name, error);
}

function errorMsg(msg, error) {
  errorElement.innerHTML += msg;
  if (typeof error !== 'undefined') {
    console.error(error);
  }
}


navigator.mediaDevices.getUserMedia(constraints).
    then(handleSuccess).catch(handleError);