<?php

//Create new CanBus interface object
$canBus = new CanBus('vcan0');

//Generate random frame
$randomCanFrame = $canBus->generateRandomFrame();
var_dump($randomCanFrame);

//Create new frame
$canFrame = new CanFrame(
    0x204, //Id
    [0x00, 0x02, 0x01, 0x00, 0x00, 0x00, 0x00, 0x08] //Data
);
var_dump($canFrame);
?>
