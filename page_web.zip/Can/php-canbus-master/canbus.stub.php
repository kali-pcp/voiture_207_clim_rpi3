<?php
class CanBus {

/**
 * CanBus constructor.
 *
 * @param string $interface non-empty string
 */
public function __construct(string $interface) {}

/**
 * Initializes CanBus interface and connects to unix sockets
 * If socket was initialized before, it closes previous connection
 *
 * @param bool $blocking Whether interface should be blocking or not
 * @return bool success/failure
 */
public function init(bool $blocking = true): bool {}

/**
 * Attempts to read single CanFrame.
 *
 * @return CanFrame|false CanFrame on success, false on failure
 */
public function read(): CanFrame|false {}

/**
 * Attempts to send single CanFrame.
 *
 * @return bool success/failure
 */
public function send(CanFrame $frame): bool {}

/**
 * Generates random CanFrame
 * ID: 0 to 0x7FF
 * Data: 0 to 8 bytes of values in range of 0 to 0xFF (0-255)
 *
 * @return CanFrame
 */
public function generateRandomFrame(): CanFrame {}
}

class CanFrame {

/**
 * CanFrame constructor.
 *
 * @param int $index value in range o 0 to 0x7FFFFFFF (CAN 2.0B)
 * @param array $data 0 to 8 bytes of values in range of 0 to 0xFF (0-255)
 */
public function __construct(int $index, array $data) {}
}
?>