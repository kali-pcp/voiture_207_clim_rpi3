<?php
/*$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$txt = "John Doe\n";
fwrite($myfile, $txt);
$txt = "Jane Doe\n";
fwrite($myfile, $txt);
fclose($myfile);*/

// http://127.0.0.1/VERSION%20PAGE%20WEB/Can/test.php?clim_text_power=%22Manuel%22&clim_speedfan_power=%2205%22&clim_temp_left=%2218%22
//clim_temp_left=${clim_temp_left}&clim_temp_right=${clim_temp_right}&bue_avant=${bue_avant}&bue_arriere=${bue_arriere}&clim_RECYLE_AIR=${clim_RECYLE_AIR}&clim_text_power=${clim_text_power}&clim_speedfan_power=${clim_speedfan_power}&clim_position=${clim_position}
/*
*   TOUT METTRE EN $_POST UNE FOIS FINI CAR JAVA SCRIPT ENVOIE TOUT EN POST 
*
*/

/*
    A INSTALLER https://github.com/adamczykpiotr/php-canbus#installation DUCOUP NON NE PAS INSTALLER
*/
//clim_temp_left=21&clim_temp_right=21&bue_avant=false&bue_arriere=false&clim_RECYLE_AIR=false&clim_text_power=OFF&clim_speedfan_power=0&clim_position=16



if($_POST['clim_text_power'] == "OFF") {
    $manuel_auto_pareprise_fan = "A2";
}else if( $_POST['clim_text_power'] == "Manuel") {
    $manuel_auto_pareprise_fan = "22";
}else if ($_POST['clim_text_power'] == "Auto") {
    $manuel_auto_pareprise_fan = "20";
}else if ($_POST['clim_text_power'] == "Auto A/C") {
    $manuel_auto_pareprise_fan = "00";
}
echo "clim text ".$manuel_auto_pareprise_fan. "<br>";

$recycle_air_fan="00";
if($_POST['clim_RECYLE_AIR'] == "true"){
    $recycle_air_fan="30";
    echo "recyclage d'air activer <br>";
}

echo "Vitesse des ventilo ".$_POST['clim_speedfan_power']."<br>"; 
$speed_fan = $_POST['clim_speedfan_power'];

$position_fan = $_POST['clim_position'];
echo "Clim Position".$position_fan."<br>"; 


echo "clim temparature Gauche ".clim_to_hex($_POST['clim_temp_left'])."<br>";
$temp_fan_LEFT=clim_to_hex($_POST['clim_temp_left']);

echo "clim temparature Droit ".clim_to_hex($_POST['clim_temp_right'])."<br>";
$temp_fan_RIGHT=clim_to_hex($_POST['clim_temp_right']);




function clim_to_hex($temp){
    if($temp == "13"){
        return "00";
    }else if ($temp == "14"){
        return "01";
    }else if ($temp == "15"){
        return "02";
    }else if ($temp == "16"){
        return "03";
    }else if ($temp == "17"){
        return "04";
    }else if ($temp == "18"){
        return "05";
    }else if ($temp == "18.5"){
        return "06";
    }else if ($temp == "19"){
        return "07";
    }else if ($temp == "19.5"){
        return "08";
    }else if ($temp == "20"){
        return "09";
    }else if ($temp == "20.5"){
        return "0A";
    }else if ($temp == "21"){
        return "0B";
    }else if ($temp == "21.5"){
        return "0C";
    }else if ($temp == "22"){
        return "0D";
    }else if ($temp == "22.5"){
        return "0E";
    }else if ($temp == "23"){
        return "0F";
    }else if ($temp == "23.5"){
        return "10";
    }else if ($temp == "24"){
        return "11";
    }else if ($temp == "25"){
        return "12";
    }else if ($temp == "26"){
        return "13";
    }else if ($temp == "27"){
        return "14";
    }else if ($temp == "28"){
        return "15";
    }else if ($temp == "29"){
        return "16";
    }
}
/* 
echo ($_POST['temp_fan_LEFT']); 
echo ($_POST['temp_fan_RIGHT']); 
echo ($_POST['recycle_air_fan']); 
echo ($_POST['position_fan']); */

$change=false;
$handle = fopen("/var/www/html/Can/save_status.txt", "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {


        if (strpos($line, 'clim_text_power:') !== false) {
            if (strcmp($line, "clim_text_power:".$_POST['clim_text_power']."\n") !== 0) { //// ATTENTION METTRE LE \n CAR DANS LE FICHIER IL Y ES 
                //CHANGEMENT DE STATUS SUR LE CLIM TEXT 
                /*if($_POST['clim_text_power'] == "OFF") {
                    $manuel_auto_pareprise_fan = "A2";
                }else if( $_POST['clim_text_power'] == "Manuel") {
                    $manuel_auto_pareprise_fan = "22";
                }else if ($_POST['clim_text_power'] == "Auto") {
                    $manuel_auto_pareprise_fan = "20";
                }else if ($_POST['clim_text_power'] == "Auto A/C") {
                    $manuel_auto_pareprise_fan = "00";
                }*/
                $change=true;
            }/*else{
                $manuel_auto_pareprise_fan=str_replace("clim_text_power:","",$line);
            }*/



        }else if (strpos($line, 'bue_arriere:') !== false) {
            if (strcmp($line, "bue_arriere:".$_POST['bue_arriere']."\n") !== 0) { //// ATTENTION METTRE LE \n CAR DANS LE FICHIER IL Y ES 
                //CHANGEMENT DE STATUS SUR bue arriere
                echo "Bue arirer ".$_POST['bue_arriere']. "<br>";
                echo "Activer/désactiver bue arriere alors mettre 'manuel' à 62";
                //$manuel_auto_pareprise_fan = 62;
                $tram="1D0#62000${speed_fan}${position_fan}${recycle_air_fan}${temp_fan_LEFT}${temp_fan_RIGHT}";
                echo $tram;
                shell_exec("cansend can0 $tram");
                shell_exec("cansend can0 $tram");
                $change=true;
            }
        }else if (strpos($line, 'bue_avant:') !== false) {
            if (strcmp($line, "bue_avant:".$_POST['bue_avant']) !== 0) {
                //CHANGEMENT DE STATUS SUR bue avant
                echo "bue_avant ".$_POST['bue_avant']. "<br>";
                if ($_POST['bue_avant'] == "true"){
                    echo "Activer bue avant alors mettre 'manuel' à 21";
                    $manuel_auto_pareprise_fan = 21;
                    $tram="1D0#21000${speed_fan}10100909";
                    shell_exec("cansend can0 $tram");
                    $change=true;
                }
            }
        }


    }
    fclose($handle);
}

if ($change == true){
    $myfile = fopen("/var/www/html/Can/save_status.txt", "w") or die("Unable to open file!");
    // SAVE STATUS
    $txt="clim_text_power:".$_POST['clim_text_power']."\nbue_arriere:".$_POST['bue_arriere']."\nbue_avant:".$_POST['bue_avant'];
    fwrite($myfile, "$txt");
    fclose($myfile);
    // POUR STOP LA CLIM DIRECT 
    shell_exec("screen -S sender -X quit && screen -S sender2 -X quit && screen -S sender3 -X quit && screen -S sender4 -X quit && screen -S sender5 -X quit");
}



if ($_POST['bue_avant'] == "true"){
    echo "Activer bue avant alors mettre 'manuel' à 21";
    $manuel_auto_pareprise_fan = 11;
    $tram="1D0#11000${speed_fan}10100909";
    echo $tram;
    shell_exec("cansend can0 $tram");
}else{
    $tram="1D0#${manuel_auto_pareprise_fan}000${speed_fan}${position_fan}${recycle_air_fan}${temp_fan_LEFT}${temp_fan_RIGHT}";
    echo $tram;
    shell_exec("cansend can0 $tram");
}



// save les status bue avant arriere 
// pour ne pas mettre 21 ou 62 quand l'utilisateur change un truc 

//si bue avant activer sur le javascript alors ne pas executer bue avant

// si bue arriere deja activer sur le javascript alors ne pas executer 

$myfile = fopen("/var/www/html/Can/can_frame.txt", "w") or die("Unable to open file!");
$txt = "$tram";
fwrite($myfile, $txt);
//$txt = "Jane Doe\n";
//fwrite($myfile, $txt);
fclose($myfile);




?> 
