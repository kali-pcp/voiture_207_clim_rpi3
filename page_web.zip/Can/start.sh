#!/bin/bash
echo sender looper
### FAN
file="data.txt"
#canoutput="/home/pi/Desktop/can_data_clim.txt"
candump_log="candump-2022-01-09_142527.log"
file_candump="/var/www/html/Can/candump.log"
file="/var/www/html/Can"
id=1
manuel_auto_pareprise_fan="00"

can_frame="1D0#00000000000000"

while [ True ]
do
    #echo "1D0# ${manuel_auto_pareprise_fan} 00 ${speed_fan} ${position_fan} ${recycle_air_fan} ${temp_fan_LEFT} ${temp_fan_RIGHT}"   ### Send DATA TO CLIM
    #cansend can0 1D0#${manuel_auto_pareprise_fan}00${speed_fan}${position_fan}${recycle_air_fan}${temp_fan_LEFT}${temp_fan_RIGHT} ### Plus activer car speed low
    #echo "1D0#${manuel_auto_pareprise_fan}00${speed_fan}${position_fan}${recycle_air_fan}${temp_fan_LEFT}${temp_fan_RIGHT}" > ${canoutput}

    if [[ $can_frame != $(cat ${file}/can_frame.txt) ]];then
        echo "fichier changer !!!"
        can_frame=$(cat ${file}/can_frame.txt)
        
        ## REFAIRE LE FICHIER KILL LE SCREEN ET START LE SCREEN 

        ## FICHIER 
        id=1 
        for i in `seq 145`
        do 
            #tram="1D0#${manuel_auto_pareprise_fan}00${speed_fan}${position_fan}${recycle_air_fan}${temp_fan_LEFT}${temp_fan_RIGHT}"
            line=$(sed -n ${id}p < ${file}/candump-2022-01-09_142527.log)
            head=$(echo ${line} | cut -d' ' -f1-2)
            sed -i "s/$(echo ${line})/${head} ${can_frame}/g" ${file}/candump-2022-01-09_142527.log ### OK
            id=$(( ${id} + 1 ))
        done 
        
        #KILL SCREEN
        screen -S sender -X quit

        #START LE SCREEN
        cp /var/www/html/Can/candump-2022-01-09_142527.log /var/www/html/Can/candump.log
        echo "start new screen"
        screen -dmS sender bash -c "canplayer -I ${file_candump}"

    fi

    if ! screen -list | grep -q "sender"; then
        echo "screen n'existe plus"
        screen -dmS sender bash -c "canplayer -I ${file_candump}"
        echo "start new screen"
    fi

    sleep 1s

    

done
