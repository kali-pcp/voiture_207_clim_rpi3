#!/bin/bash
if [[ $(echo cc$(sudo ip a | grep can0)) != "cc" ]]; then 
    sudo modprobe can_raw && sudo modprobe can_dev && sudo ip link set can0 up type can bitrate 125000 sample-point 0.875
else
    #sudo modprobe vcan && sudo ip link add dev can0 type vcan && sudo ip link set up can0 && ip a
fi
#screen -dmS application bash -c "bash /var/www/html/Can/start.sh"
