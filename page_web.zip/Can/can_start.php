<?php


$manuel_auto_pareprise_fan="21";
$speed_fan="00";

/*
if [[ ${manuel_auto_pareprise_fan} == "21" || ${manuel_auto_pareprise_fan} == "11" ]] && [[ ${speed_fan} == "0F" ]];then
                speed_fan=00
            fi
*/

if ( ($manuel_auto_pareprise_fan == "21" || $manuel_auto_pareprise_fan == "11") && $speed_fan == "0F" ){
    $speed_fan="00";
}
/* METTRE TOUT POUR FAIRE LA TRAME  */

$tram="1D0#${manuel_auto_pareprise_fan}00${speed_fan}${position_fan}${recycle_air_fan}${temp_fan_LEFT}${temp_fan_RIGHT}";
echo $tram;

/* FAIRE UN SCRENN AVEC LE PLAYCAN LE STOP QUAND ON BOUGE LE START QUAND C4EST BON  */

?>