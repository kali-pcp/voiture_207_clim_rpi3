<?php

include_once("php-canbus-master/canbus.stub.php");


//Create new CanBus interface object
$canBus = new CanBus('can0');

//Initialize interface (connect to unix socket)
if($canBus->init() === false) {
    //Handle error
}

//Create new frame
$canFrame = new CanFrame(
    0x204,
    [0x00, 0x02, 0x01]
);

//Send new frame
if($canBus->send($canFrame) === false) {
    //Handle error
}

?>
