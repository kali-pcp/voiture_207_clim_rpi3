## FOR Raspbian Bullseye
sudo apt update -y 
sudo apt upgrade -y 
sudo apt install dkms git can-utils apache2 openssl screen php openbox screen xinit chromium-browser raspberrypi-kernel raspberrypi-kernel-headers -y 

### https 
sudo su
a2enmod ssl
a2enmod rewrite
vi /etc/apache2/apache2.conf
## ajouter à la fin 
<Directory /var/www/html>
AllowOverride All
</Directory>

mkdir /etc/apache2/certificate
cd /etc/apache2/certificate
openssl req -new -newkey rsa:4096 -x509 -sha256 -days 365 -nodes -out apache-certificate.crt -keyout apache.key

## PUIS VOIR SITE https://techexpert.tips/fr/apache-fr/activer-https-sur-apache/

#git clone https://github.com/krumboeck/usb2can
#mv usb2can /usr/src/usb2can-1.0
#dkms add -m usb2can -v 1.0 --verbose
#dkms build -m usb2can -v 1.0 --verbose
#dkms install -m usb2can -v 1.0 --verbose
#sudo apt-get install raspberrypi-kernel raspberrypi-kernel-headers
su pi
cd 
git clone https://github.com/8devices/usb2can.git
cd usb2can
make 
sudo make install
sudo depmod -a
echo debrancher can usb et reboot

# echo ----BOOT---- openbox à ne plus utiliser
# sudo su
# sudo sed -i '/exit 0/d' /etc/rc.local
# sudo echo "startx &">> /etc/rc.local
# sudo echo "exit 0">> /etc/rc.local
# sudo sed -i 's+. /etc/X11/Xsession+#. /etc/X11/Xsession+g' /etc/X11/xinit/xinitrc
# sudo echo "exec openbox-session" >> /etc/X11/xinit/xinitrc
# sudo echo "/bin/bash /home/pi/app.sh &" >> /etc/xdg/openbox/autostart

### LIEN https://blog.r0b.io/post/minimal-rpi-kiosk/
### LIGNE POUR LANCER Le CAN
# sudo echo "bash /var/www/html/Can/Setup.sh" >> /home/pi/app.sh
# sudo echo "chromium-browser --kiosk --touch-events=enabled --disable-pinch --noerrdialogs --disable-session-crashed-bubble --simulate-outdated-no-au='Tue, 31 Dec 2099 23:59:59 GMT' --disable-component-update --overscroll-history-navigation=0 --disable-features=TranslateUI --app=127.0.0.1" >> /home/pi/app.sh
su pi
touch /home/pi/.bash_profile
echo "if [ -z \$DISPLAY ] && [ \$(tty) = /dev/tty1 ]" >> /home/pi/.bash_profile
echo "then" >> /home/pi/.bash_profile
echo "  bash /var/www/html/Can/Setup.sh" >> /home/pi/.bash_profile
echo "  startx" >> /home/pi/.bash_profile
echo "fi" >> /home/pi/.bash_profile
touch /home/pi/.xinitrc

# à ecrire dans /home/pi/.xinitrc
#!/usr/bin/env sh
xset -dpms
xset s off
xset s noblank
unclutter &
chromium-browser https://127.0.0.1 \
  --window-size=1024,600 \
  --window-position=0,0 \
  --start-fullscreen \
  --kiosk \
  --incognito \
  --noerrdialogs \
  --disable-translate \
  --no-first-run \
  --fast \
  --fast-start \
  --disable-infobars \
  --disable-features=TranslateUI \
  --disk-cache-dir=\/dev\/null \
  --overscroll-history-navigation=0 \
  --disable-pinch
reboot

# echo -e $start >> /home/pi/.xinitrc

# chmod +x /home/pi/app.sh

sudo su
### dans nano /boot/config.txt ajouter:
echo "max_usb_currenct = 1" >> /boot/config.txt
echo "hdmi_force_hotplug = 1" >> /boot/config.txt
echo "config_hdmi_boost = 10" >> /boot/config.txt
echo "hdmi_group = 2" >> /boot/config.txt
echo "hdmi_mode = 87" >> /boot/config.txt
echo "hdmi_cvt 1024 600 60 6 0 0 0" >> /boot/config.txt
echo "disable_overscan=1" >> /boot/config.txt

cd /var/www/html
git clone https://github.com/kali-pcp/voiture_207_clim_rpi3
rm index.html
mv voiture_207_clim_rpi3/page_web.zip /var/www/html/
rm -rf voiture_207_clim_rpi3/
unzip page_web.zip
chown -R www-data:www-data /var/www/html/*

reboot


## FAST BOOT 

#BLEUTHOO
sudo echo dtoverlay=disable-bt >> /boot/config.txt
sudo systemctl disable hciuart

# Disable rainbow image at boot
sudo echo disable_splash=1 >> /boot/config.txt
# Black border
sudo echo disable_overscan=1 >> /boot/config.txt
# Set the bootloader delay to 0 seconds. The default is 1s if not specified.
sudo echo boot_delay=0 >> /boot/config.txt

# systemctl stop dhcpcd
# systemctl disable dhcpcd
 