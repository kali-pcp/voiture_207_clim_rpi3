## FOR Raspbian Bullseye
sudo apt update -y 
sudo apt upgrade -y 
sudo apt install dkms git can-utils apache2 screen php openbox screen xinit chromium-browser -y 

#git clone https://github.com/krumboeck/usb2can
#mv usb2can /usr/src/usb2can-1.0
#dkms add -m usb2can -v 1.0 --verbose
#dkms build -m usb2can -v 1.0 --verbose
#dkms install -m usb2can -v 1.0 --verbose
sudo apt-get update
sudo apt-get install git raspberrypi-kernel raspberrypi-kernel-headers


git clone https://github.com/8devices/usb2can.git
cd usb2can
make 
sudo make install
sudo depmod -a
echo debrancher can usb et reboot

# echo ----BOOT---- openbox à ne plus utiliser
# sudo su
# sudo sed -i '/exit 0/d' /etc/rc.local
# sudo echo "startx &">> /etc/rc.local
# sudo echo "exit 0">> /etc/rc.local
# sudo sed -i 's+. /etc/X11/Xsession+#. /etc/X11/Xsession+g' /etc/X11/xinit/xinitrc
# sudo echo "exec openbox-session" >> /etc/X11/xinit/xinitrc
# sudo echo "/bin/bash /home/pi/app.sh &" >> /etc/xdg/openbox/autostart

### LIEN https://blog.r0b.io/post/minimal-rpi-kiosk/
### LIGNE POUR LANCER Le CAN
# sudo echo "bash /var/www/html/Can/Setup.sh" >> /home/pi/app.sh
# sudo echo "chromium-browser --kiosk --touch-events=enabled --disable-pinch --noerrdialogs --disable-session-crashed-bubble --simulate-outdated-no-au='Tue, 31 Dec 2099 23:59:59 GMT' --disable-component-update --overscroll-history-navigation=0 --disable-features=TranslateUI --app=127.0.0.1" >> /home/pi/app.sh
su pi
touch /home/pi/.bash_profile
echo "if [ -z \$DISPLAY ] && [ \$(tty) = /dev/tty1 ]" >> /home/pi/.bash_profile
echo "then" >> /home/pi/.bash_profile
echo "  bash /var/www/html/Can/Setup.sh" >> /home/pi/.bash_profile
echo "  startx" >> /home/pi/.bash_profile
echo "fi" >> /home/pi/.bash_profile
touch /home/pi/.xinitrc

# à ecrire dans home/pi/.xinitrc
#!/usr/bin/env sh
xset -dpms
xset s off
xset s noblank
unclutter &
chromium-browser http://127.0.0.1 \
  --window-size=1366,768 \
  --window-position=0,0 \
  --start-fullscreen \
  --kiosk \
  --incognito \
  --noerrdialogs \
  --disable-translate \
  --no-first-run \
  --fast \
  --fast-start \
  --disable-infobars \
  --disable-features=TranslateUI \
  --disk-cache-dir=\/dev\/null \
  --overscroll-history-navigation=0 \
  --disable-pinch

# echo -e $start >> /home/pi/.xinitrc

# chmod +x /home/pi/app.sh

su root
### dans nano /boot/config.txt ajouter:
echo "max_usb_currenct = 1" >> /boot/config.txt
echo "hdmi_force_hotplug = 1" >> /boot/config.txt
echo "config_hdmi_boost = 10" >> /boot/config.txt
echo "hdmi_group = 2" >> /boot/config.txt
echo "hdmi_mode = 87" >> /boot/config.txt
echo "hdmi_cvt 1024 600 60 6 0 0 0" >> /boot/config.txt
echo "disable_overscan=1" >> /boot/config.txt

